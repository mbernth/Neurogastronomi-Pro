$(document).ready(function(){

		
		$('.caption-5').click(function(){
			
			$(this).toggleClass("flip");
			
		});

		

	});
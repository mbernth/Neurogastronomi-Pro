// Basic FitVids Test
$(".site-inner").fitVids();
$(".fittext1").fitText();